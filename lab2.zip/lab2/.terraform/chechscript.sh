#!/bin/bash
 if  /usr/sbin/nginx -t 2>/dev/null; then
       echo 'nginx server is up'
      else
        service nginx restart
      fi
